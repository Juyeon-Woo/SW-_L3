package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAO {
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			
			public Connection getConnection() throws SQLException {
				String jdbc_driver="oracle.jdbc.OracleDriver";
				String db_url="jdbc:oracle:thin:@localhost:1521:xe";
				try {
					Class.forName(jdbc_driver);
					Connection conn = DriverManager.getConnection(db_url,"system","123456");
					return conn;
				} catch (Exception e) {
					e.printStackTrace();
				}
				return null;
			}
		
	
	public ArrayList<MemberVO> readList() throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ArrayList<MemberVO> member = new ArrayList<MemberVO>();
		try {
			conn = getConnection();
			sql = "Select * from personnel";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				do {
					MemberVO cst = new MemberVO();
					cst.setId(rs.getString(1));
					cst.setName(rs.getString(2));
					cst.setDept(rs.getString(3));
					cst.setPosition(rs.getString(4));
					cst.setDuty(rs.getString(5));
					cst.setPhone(rs.getString(6));
					member.add(cst);
				} while (rs.next());
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}if(pstmt!=null) {
				try {
					pstmt.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(conn!=null) {
				try {
					conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		return member;
	}
	
	public ArrayList<MemberVO> resultMember(String searchType, String id, String dept) throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ArrayList<MemberVO> member = new ArrayList<MemberVO>();
		try {
			conn=getConnection();
			if(searchType.contentEquals("sid")) {
				sql = "select * from personnel where id=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
			}else {
				sql="select * from personnel where dept=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, dept);
			} rs=pstmt.executeQuery();
			if(rs.next()) {
				do {
					MemberVO cst = new MemberVO();
					cst.setId(rs.getString(1));
					cst.setName(rs.getString(2));
					cst.setDept(rs.getString(3));
					cst.setPosition(rs.getString(4));
					cst.setDuty(rs.getString(5));
					cst.setPhone(rs.getString(6));
					member.add(cst);
				}while(rs.next());
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs !=null) rs.close();
				if(pstmt !=null)pstmt.close();
				if(conn !=null)conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return member;
	}
	
	public void addMember(String id, String name, String dept, String position, String duty, String phone)throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			conn = getConnection();
			sql="insert into personnel values(?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);
			pstmt.setString(2,name);
			pstmt.setString(3,dept);
			pstmt.setString(4,position);
			pstmt.setString(5,duty);
			pstmt.setString(6,phone);
			pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(pstmt!=null) {
				try {
					pstmt.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(conn!=null) {
				try {
					conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	public void deleteMember(String id, String name)throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			conn = getConnection();
			sql="delete from personnel where id=? and name=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);
			pstmt.setString(2,name);
			pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(pstmt!=null) {
				try {
					pstmt.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(conn!=null) {
				try {
					conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	public void changeMember(String id, String name, String dept, String position, String duty, String phone)throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			conn = getConnection();
			sql="update personnel set name=?, dept=?, positon=?, duty=?, phone=?, where id=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, name);
			pstmt.setString(2,dept);
			pstmt.setString(3,position);
			pstmt.setString(4,duty);
			pstmt.setString(5,phone);
			pstmt.setString(6,id);
			pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(rs!=null) {
				try {
					rs.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(pstmt!=null) {
				try {
					pstmt.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}if(conn!=null) {
				try {
					conn.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}